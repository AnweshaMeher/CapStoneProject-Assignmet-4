#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstring>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#define CLOSESOCKET closesocket
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#define CLOSESOCKET close
#endif

using namespace std;

void send_string(SOCKET sock, const string &msg) {
    int len = msg.size();
    send(sock, (char*)&len, sizeof(len), 0);
    send(sock, msg.c_str(), len, 0);
}

bool recv_string(SOCKET sock, string &out) {
    int len;
    if (recv(sock, (char*)&len, sizeof(len), 0) <= 0) return false;
    vector<char> buf(len + 1, 0);
    if (recv(sock, buf.data(), len, 0) <= 0) return false;
    out = buf.data();
    return true;
}

int main() {
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in serv{};
    serv.sin_family = AF_INET;
    serv.sin_port = htons(9000);
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);

    if (connect(sock, (sockaddr*)&serv, sizeof(serv)) < 0) {
        cerr << "❌ Could not connect to server.\n";
        return 1;
    }

    string user, pass;
    cout << "Username: "; getline(cin, user);
    cout << "Password: "; getline(cin, pass);
    send_string(sock, user);
    send_string(sock, pass);

    string response;
    if (!recv_string(sock, response) || response != "AUTH_OK") {
        cout << "❌ Authentication failed.\n";
        CLOSESOCKET(sock);
        return 0;
    }

    cout << "✅ Login successful!\n";

    while (true) {
        cout << "\n--- MENU ---\n";
        cout << "1. List files\n2. Download file\n3. Upload file\n4. Quit\n";
        cout << "Choice: ";
        string choice;
        getline(cin, choice);

        if (choice == "1") {
            send_string(sock, "LIST");
            string files;
            recv_string(sock, files);
            cout << "\nFiles on Server:\n" << files;
        }
        else if (choice == "2") {
            cout << "Enter filename to download: ";
            string fname;
            getline(cin, fname);
            send_string(sock, "DOWNLOAD " + fname);
            string status;
            recv_string(sock, status);
            if (status == "ERR_NOFILE") {
                cout << "❌ File not found.\n";
                continue;
            } else if (status == "READY") {
                int size;
                recv(sock, (char*)&size, sizeof(size), 0);
                ofstream file(fname, ios::binary);
                char buffer[1024];
                int received = 0;
                while (received < size) {
                    int bytes = recv(sock, buffer, sizeof(buffer), 0);
                    if (bytes <= 0) break;
                    file.write(buffer, bytes);
                    received += bytes;
                }
                file.close();
                cout << "✅ File downloaded: " << fname << endl;
            }
        }
        else if (choice == "3") {
            cout << "Enter local file to upload: ";
            string path;
            getline(cin, path);
            ifstream file(path, ios::binary);
            if (!file.is_open()) {
                cout << "❌ File not found.\n";
                continue;
            }
            file.seekg(0, ios::end);
            int size = file.tellg();
            file.seekg(0);

            send_string(sock, "UPLOAD");
            string reply;
            recv_string(sock, reply);
            if (reply == "SEND_META") {
                string meta = path.substr(path.find_last_of("/\\") + 1) + "|" + to_string(size);
                send_string(sock, meta);
                char buffer[1024];
                while (file.read(buffer, sizeof(buffer)) || file.gcount()) {
                    send(sock, buffer, file.gcount(), 0);
                }
                file.close();
                string status;
                recv_string(sock, status);
                cout << "Server: " << status << endl;
            }
        }
        else if (choice == "4") {
            send_string(sock, "QUIT");
            cout << "👋 Exiting...\n";
            break;
        }
    }

    CLOSESOCKET(sock);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
