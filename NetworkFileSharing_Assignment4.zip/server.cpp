#include <iostream>
#include <fstream>
#include <thread>
#include <vector>
#include <string>
#include <cstring>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#define CLOSESOCKET closesocket
#define SOCKLEN_T int
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#define CLOSESOCKET close
#define SOCKLEN_T socklen_t
#endif

using namespace std;

const string USER = "admin";
const string PASS = "password123";
const int PORT = 9000;

void send_string(SOCKET sock, const string &msg) {
    int len = msg.size();
    send(sock, (char*)&len, sizeof(len), 0);
    send(sock, msg.c_str(), len, 0);
}

bool recv_string(SOCKET sock, string &out) {
    int len;
    int r = recv(sock, (char*)&len, sizeof(len), 0);
    if (r <= 0) return false;
    vector<char> buffer(len + 1, 0);
    r = recv(sock, buffer.data(), len, 0);
    if (r <= 0) return false;
    out = buffer.data();
    return true;
}

void handle_client(SOCKET client) {
    cout << "[+] Client connected.\n";
    string user, pass;
    if (!recv_string(client, user)) return;
    if (!recv_string(client, pass)) return;

    if (user != USER || pass != PASS) {
        send_string(client, "AUTH_FAIL");
        CLOSESOCKET(client);
        cout << "[-] Invalid credentials.\n";
        return;
    }
    send_string(client, "AUTH_OK");
    cout << "[+] Authenticated: " << user << "\n";

    while (true) {
        string cmd;
        if (!recv_string(client, cmd)) break;

        if (cmd == "LIST") {
            system("dir /b > server_files.txt");
            ifstream in("server_files.txt");
            string line, data;
            while (getline(in, line)) data += line + "\n";
            in.close();
            send_string(client, data);
        }
        else if (cmd.rfind("DOWNLOAD ", 0) == 0) {
            string filename = cmd.substr(9);
            ifstream file(filename, ios::binary);
            if (!file.is_open()) {
                send_string(client, "ERR_NOFILE");
                continue;
            }
            send_string(client, "READY");
            file.seekg(0, ios::end);
            int size = file.tellg();
            file.seekg(0);
            send(client, (char*)&size, sizeof(size), 0);
            char buffer[1024];
            while (file.read(buffer, sizeof(buffer)) || file.gcount()) {
                send(client, buffer, file.gcount(), 0);
            }
            file.close();
            cout << "[>] Sent file: " << filename << endl;
        }
        else if (cmd == "UPLOAD") {
            send_string(client, "SEND_META");
            string meta;
            if (!recv_string(client, meta)) break;
            auto pos = meta.find('|');
            string filename = meta.substr(0, pos);
            int size = stoi(meta.substr(pos + 1));
            ofstream out(filename, ios::binary);
            int received = 0;
            char buffer[1024];
            while (received < size) {
                int bytes = recv(client, buffer, sizeof(buffer), 0);
                if (bytes <= 0) break;
                out.write(buffer, bytes);
                received += bytes;
            }
            out.close();
            send_string(client, "UPLOAD_OK");
            cout << "[<] Received file: " << filename << endl;
        }
        else if (cmd == "QUIT") {
            cout << "[-] Client disconnected.\n";
            break;
        }
    }
    CLOSESOCKET(client);
}

int main() {
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif

    SOCKET server_fd = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_fd, (sockaddr*)&addr, sizeof(addr));
    listen(server_fd, 5);
    cout << "📡 Server listening on port " << PORT << "...\n";

    while (true) {
        sockaddr_in client_addr{};
        SOCKLEN_T len = sizeof(client_addr);
        SOCKET client_sock = accept(server_fd, (sockaddr*)&client_addr, &len);
        if (client_sock == INVALID_SOCKET) continue;
        thread(handle_client, client_sock).detach();
    }

#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
